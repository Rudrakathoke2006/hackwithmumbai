import { motion, AnimatePresence } from "motion/react";
import { 
  Wallet, 
  Mail, 
  Lock, 
  ArrowRight, 
  Shield, 
  Zap, 
  Database, 
  Ghost,
  Coins,
  User
} from "lucide-react";
import React, { useState } from "react";

const BackgroundAnimation = () => {
  return (
    <div className="fixed inset-0 -z-10 bg-slate-950 overflow-hidden">
      {/* Geometric Grid */}
      <div 
        className="absolute inset-0 opacity-[0.15]" 
        style={{
          backgroundImage: `linear-gradient(to right, #1e293b 1px, transparent 1px), linear-gradient(to bottom, #1e293b 1px, transparent 1px)`,
          backgroundSize: '4rem 4rem'
        }}
      />
      
      {/* Animated Glowing Orbs */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-brand-cyan/20 blur-[120px] rounded-full animate-pulse-slow" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-brand-purple/20 blur-[120px] rounded-full animate-pulse-slow" style={{ animationDelay: '2s' }} />

      {/* Modern Svg Network Pattern */}
      <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="dots" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.5" fill="#475569" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#dots)" />
        <motion.path
          d="M0 100 Q 250 50 500 100 T 1000 100"
          fill="none"
          stroke="url(#gradient)"
          strokeWidth="1"
          strokeDasharray="10 5"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 1 }}
          transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
        />
        <linearGradient id="gradient">
          <stop offset="0%" stopColor="#00f2ff" />
          <stop offset="100%" stopColor="#bc13fe" />
        </linearGradient>
      </svg>
    </div>
  );
};

export default function App() {
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <BackgroundAnimation />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="w-full max-w-md"
      >
        {/* Branding/Logo Area */}
        <div className="flex flex-col items-center mb-8">
          <motion.div 
            whileHover={{ rotate: 180 }}
            transition={{ duration: 0.6 }}
            className="w-16 h-16 rounded-2xl bg-gradient-to-br from-brand-cyan to-brand-purple p-0.5 mb-4 shadow-lg glow-cyan"
          >
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Zap className="w-8 h-8 text-white fill-brand-cyan" />
            </div>
          </motion.div>
          <h1 className="text-3xl font-bold tracking-tight text-white mb-2">
            Block<span className="text-brand-cyan">Brute</span>
          </h1>
          <p className="text-slate-400 text-sm font-medium">
            {mode === "signin" ? "Access the Decentralized Web" : "Join the Decentralized Future"}
          </p>
        </div>

        {/* Main Card */}
        <div className="glass rounded-3xl p-8 shadow-2xl relative overflow-hidden">
          {/* Subtle top light effect */}
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-right from-transparent via-white/20 to-transparent" />

          <AnimatePresence mode="wait">
            <motion.div
              key={mode}
              initial={{ opacity: 0, x: mode === "signin" ? -20 : 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: mode === "signin" ? 20 : -20 }}
              transition={{ duration: 0.3 }}
              className="space-y-6"
            >
              {/* Wallet Connection Section */}
              <div className="space-y-3">
                <p className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">Secure Connection</p>
                
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  id="connect-wallet-btn"
                  className="w-full flex items-center justify-between px-6 py-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl transition-all group relative overflow-hidden"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-brand-cyan/10 rounded-lg group-hover:bg-brand-cyan/20 transition-colors">
                      <Wallet className="w-5 h-5 text-brand-cyan" />
                    </div>
                    <span className="font-semibold text-white">Connect Wallet</span>
                  </div>
                  <div className="flex -space-x-2">
                    <div className="w-8 h-8 rounded-full bg-slate-800 border-2 border-slate-900 flex items-center justify-center p-1.5" title="MetaMask">
                      <Ghost className="w-full h-full text-orange-500" />
                    </div>
                    <div className="w-8 h-8 rounded-full bg-slate-800 border-2 border-slate-900 flex items-center justify-center p-1.5" title="WalletConnect">
                      <Database className="w-full h-full text-blue-400" />
                    </div>
                  </div>
                  
                  {/* Glow effect on hover */}
                  <div className="absolute inset-0 bg-brand-cyan/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                </motion.button>
              </div>

              {/* Divider */}
              <div className="relative py-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-white/5"></div>
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-slate-925 px-4 text-slate-500 font-bold tracking-widest">
                    {mode === "signin" ? "or continue with email" : "or set up credentials"}
                  </span>
                </div>
              </div>

              {/* Traditional Form */}
              <form onSubmit={handleAuth} className="space-y-4">
                {mode === "signup" && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="space-y-2"
                  >
                    <label className="text-sm font-medium text-slate-300 ml-1">Full Name</label>
                    <div className="relative group">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-brand-cyan transition-colors" />
                      <input
                        type="text"
                        required
                        id="name-input"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="w-full bg-slate-900/50 border border-white/5 rounded-2xl py-3.5 pl-12 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-cyan/50 focus:border-brand-cyan/50 transition-all font-medium"
                        placeholder="John Doe"
                      />
                    </div>
                  </motion.div>
                )}

                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-300 ml-1">Email Address</label>
                  <div className="relative group">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-brand-cyan transition-colors" />
                    <input
                      type="email"
                      required
                      id="email-input"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-slate-900/50 border border-white/5 rounded-2xl py-3.5 pl-12 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-cyan/50 focus:border-brand-cyan/50 transition-all font-medium"
                      placeholder="name@example.com"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center px-1">
                    <label className="text-sm font-medium text-slate-300">Password</label>
                    {mode === "signin" && (
                      <button type="button" className="text-xs font-bold text-brand-cyan hover:text-brand-cyan/80 transition-colors uppercase tracking-tight">
                        Forgot?
                      </button>
                    )}
                  </div>
                  <div className="relative group">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-brand-cyan transition-colors" />
                    <input
                      type="password"
                      required
                      id="password-input"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-slate-900/50 border border-white/5 rounded-2xl py-3.5 pl-12 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-cyan/50 focus:border-brand-cyan/50 transition-all font-medium"
                      placeholder="••••••••"
                    />
                  </div>
                </div>

                {mode === "signup" && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="space-y-2"
                  >
                    <label className="text-sm font-medium text-slate-300 ml-1">Confirm Password</label>
                    <div className="relative group">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-brand-cyan transition-colors" />
                      <input
                        type="password"
                        required
                        id="confirm-password-input"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="w-full bg-slate-900/50 border border-white/5 rounded-2xl py-3.5 pl-12 pr-4 text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-brand-cyan/50 focus:border-brand-cyan/50 transition-all font-medium"
                        placeholder="••••••••"
                      />
                    </div>
                  </motion.div>
                )}

                <motion.button
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  type="submit"
                  id="auth-submit-btn"
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-brand-cyan to-brand-purple text-white font-bold py-4 rounded-2xl shadow-lg shadow-brand-cyan/20 hover:shadow-brand-cyan/40 transition-all flex items-center justify-center gap-2 group disabled:opacity-70"
                >
                  {isLoading ? (
                    <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      {mode === "signin" ? "Sign In" : "Create Account"}
                      <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </>
                  )}
                </motion.button>
              </form>

              {/* Toggle Mode */}
              <div className="text-center pt-2">
                <p className="text-slate-400 text-sm">
                  {mode === "signin" ? "New to BlockBrute?" : "Already have an account?"}{" "}
                  <button 
                    onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
                    className="text-white font-bold hover:text-brand-cyan transition-colors underline underline-offset-4 decoration-brand-cyan/30"
                  >
                    {mode === "signin" ? "Create Account" : "Sign In"}
                  </button>
                </p>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Security Badges */}
        <div className="mt-8 flex justify-center gap-8 opacity-40 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-500">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-brand-cyan" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">AES-256 Encrypted</span>
          </div>
          <div className="flex items-center gap-2">
            <Coins className="w-4 h-4 text-brand-purple" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Multi-Chain Verified</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
